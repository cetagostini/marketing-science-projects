# -*- coding: utf-8 -*-
"""
Created on Thu Jun 10 00:36:16 2021

@author: Carlos Trujillo
"""

from py_admetricks.pymetricks import admetricks_api