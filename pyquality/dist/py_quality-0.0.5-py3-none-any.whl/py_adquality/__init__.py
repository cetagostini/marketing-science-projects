# -*- coding: utf-8 -*-
"""
Created on Sat Jun  5 03:32:43 2021

@author: Carlos Trujillo
"""

from py_adquality.pyquality import adquality_reports